-- Upgrade aman untuk database ARISAN FRIEND JAKARTA yang sudah memakai skema awal.
alter table public.groups
  add column if not exists payment_frequency text not null default 'Fleksibel';
alter table public.groups alter column name set default 'ARISAN KELUARGA';
alter table public.groups alter column contribution_amount set default 10000;

update public.groups
set name = 'ARISAN KELUARGA', contribution_amount = 10000, payment_frequency = 'Fleksibel'
where name = 'ARISAN FRIEND JAKARTA';

-- Bendahara boleh membaca daftar periode, tetapi hanya Admin yang mengelola periode.
drop policy if exists "staff manage periods" on public.periods;
drop policy if exists "admin manage periods" on public.periods;
drop policy if exists "staff read periods" on public.periods;
create policy "staff read periods" on public.periods
  for select to authenticated using (public.is_staff());
create policy "admin manage periods" on public.periods
  for all to authenticated
  using (public.current_role() = 'admin')
  with check (public.current_role() = 'admin');
