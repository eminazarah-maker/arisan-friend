import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const anonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  if (url.isEmpty || anonKey.isEmpty) {
    runApp(const ProviderScope(child: ConfigurationRequiredApp()));
    return;
  }
  await Supabase.initialize(url: url, anonKey: anonKey);
  runApp(const ProviderScope(child: ArisanApp()));
}

class ConfigurationRequiredApp extends StatelessWidget {
  const ConfigurationRequiredApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'ARISAN KELUARGA',
    theme: ThemeData(colorSchemeSeed: const Color(0xFF8B42C7), useMaterial3: true),
    home: const Scaffold(body: Center(child: Padding(
      padding: EdgeInsets.all(24),
      child: Text('ARISAN KELUARGA\nKonfigurasi Supabase belum tersedia. Atur SUPABASE_URL dan SUPABASE_ANON_KEY pada proses build APK.'),
    ))),
  );
}
