import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PaymentsScreen extends StatefulWidget { const PaymentsScreen({super.key}); @override State<PaymentsScreen> createState()=>_PaymentsScreenState(); }
class _PaymentsScreenState extends State<PaymentsScreen>{
 final db=Supabase.instance.client;
 String rupiah(num n)=>'Rp ${n.toStringAsFixed(0).replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'),(m)=>'.')}';
 Future<void> record() async {
  final members=await db.from('members').select('id,full_name').eq('is_active',true).order('full_name');
  final periods=await db.from('periods').select('id,name').order('created_at',ascending:false);
  final group=await db.from('groups').select('contribution_amount').limit(1).maybeSingle();
  if(!mounted)return;
  if(members.isEmpty||periods.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Tambahkan anggota dan periode arisan terlebih dahulu.')));return;}
  String member=members.first['id'], period=periods.first['id'], status='paid'; final amount=TextEditingController(text:'${group?['contribution_amount']??10000}');
  final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text('Catat pembayaran'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
   DropdownButtonFormField<String>(value:member,items:members.map<DropdownMenuItem<String>>((m)=>DropdownMenuItem(value:m['id'],child:Text(m['full_name']))).toList(),onChanged:(v)=>setD(()=>member=v!),decoration:const InputDecoration(labelText:'Anggota')),
   const SizedBox(height:10),DropdownButtonFormField<String>(value:period,items:periods.map<DropdownMenuItem<String>>((p)=>DropdownMenuItem(value:p['id'],child:Text(p['name']))).toList(),onChanged:(v)=>setD(()=>period=v!),decoration:const InputDecoration(labelText:'Periode')),
   const SizedBox(height:10),TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Nominal (Rp)')),
   const SizedBox(height:10),DropdownButtonFormField<String>(value:status,items:const [DropdownMenuItem(value:'paid',child:Text('Lunas')),DropdownMenuItem(value:'pending',child:Text('Belum lunas'))],onChanged:(v)=>setD(()=>status=v!),decoration:const InputDecoration(labelText:'Status')),
  ])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Simpan'))])));
  final value=int.tryParse(amount.text.replaceAll('.','').replaceAll(',','').trim());
  if(ok==true&&value!=null&&value>0){
   try { await db.from('payments').upsert({'member_id':member,'period_id':period,'amount':value,'status':status,'paid_at':status=='paid'?DateTime.now().toIso8601String():null,'recorded_by':db.auth.currentUser?.id},onConflict:'member_id,period_id'); if(mounted)setState((){}); }
   catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Gagal mencatat pembayaran: $e')));}
  } else if(ok==true && mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Nominal harus lebih dari nol.'))); }
 }
 @override Widget build(BuildContext context)=>Scaffold(floatingActionButton:FloatingActionButton.extended(onPressed:record,icon:const Icon(Icons.add),label:const Text('Catat iuran')),
 body:FutureBuilder<List<dynamic>>(future:db.from('payments').select('id,amount,status,paid_at,members(full_name),periods(name)').order('created_at',ascending:false),builder:(c,s){
 if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());if(s.hasError)return Center(child:Text('Error: ${s.error}'));
 final rows=s.data??[]; final total=rows.where((p)=>p['status']=='paid').fold<num>(0,(v,p)=>v+(p['amount'] as num));
 return Column(children:[Container(width:double.infinity,margin:const EdgeInsets.all(12),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:const Color(0xFF49305D),borderRadius:BorderRadius.circular(18)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('TOTAL PEMBAYARAN LUNAS'),const SizedBox(height:6),Text(rupiah(total),style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold))]),),Expanded(child:rows.isEmpty?const Center(child:Text('Belum ada pembayaran tercatat.')):ListView(children:rows.map((p)=>Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:4),child:ListTile(leading:Icon(p['status']=='paid'?Icons.check_circle:Icons.pending,color:p['status']=='paid'?const Color(0xFFE84A9B):Colors.orange),title:Text(p['members']?['full_name']??'Anggota'),subtitle:Text('${p['periods']?['name']??'-'} • ${p['paid_at']??'Belum dibayar'}'),trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[Text(rupiah(p['amount'] as num),style:const TextStyle(fontWeight:FontWeight.bold)),Text(p['status']=='paid'?'LUNAS':'TERTUNDA',style:const TextStyle(fontSize:10,color:Colors.white60))])))).toList()))]);
 }));
}
