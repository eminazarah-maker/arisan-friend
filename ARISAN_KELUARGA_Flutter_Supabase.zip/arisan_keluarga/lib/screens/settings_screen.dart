import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override State<SettingsScreen> createState() => _SettingsScreenState();
}
class _SettingsScreenState extends State<SettingsScreen> {
  final db = Supabase.instance.client;
  final name = TextEditingController();
  final amount = TextEditingController(text: '10000');
  final frequency = TextEditingController(text: 'Fleksibel');
  String? groupId;
  bool loading = true, saving = false;
  String role = 'treasurer';
  List<dynamic> periods = [];
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    try {
      final profile = await db.from('profiles').select('role').eq('id', db.auth.currentUser!.id).maybeSingle();
      final group = await db.from('groups').select().order('created_at').limit(1).maybeSingle();
      final p = await db.from('periods').select().order('created_at', ascending: false);
      if (!mounted) return;
      role = profile?['role'] ?? 'treasurer'; periods = p;
      if (group != null) {
        groupId = group['id']; name.text = group['name'] ?? 'ARISAN KELUARGA';
        amount.text = '${group['contribution_amount'] ?? 10000}';
        frequency.text = group['payment_frequency'] ?? 'Fleksibel';
      }
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal memuat pengaturan: $e'))); }
    if (mounted) setState(() => loading = false);
  }
  Future<void> save() async {
    final value = int.tryParse(amount.text.replaceAll('.', '').replaceAll(',', '').trim());
    if (name.text.trim().isEmpty || value == null || value < 1) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nama dan nominal iuran harus diisi dengan benar.'))); return;
    }
    setState(() => saving = true);
    try {
      final data = {'name': name.text.trim(), 'contribution_amount': value, 'payment_frequency': frequency.text.trim().isEmpty ? 'Fleksibel' : frequency.text.trim()};
      if (groupId == null) { final row = await db.from('groups').insert(data).select('id').single(); groupId = row['id']; }
      else { await db.from('groups').update(data).eq('id', groupId!); }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pengaturan arisan tersimpan.')));
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menyimpan: $e'))); }
    if (mounted) setState(() => saving = false);
  }
  Future<void> addPeriod() async {
    final title = TextEditingController(); final date = DateTime.now();
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('Buat periode arisan'), content: TextField(controller: title, decoration: const InputDecoration(labelText: 'Nama periode', hintText: 'Contoh: Putaran 1 - November')),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Buat'))]));
    if (ok != true || title.text.trim().isEmpty) return;
    try {
      if (groupId == null) await save();
      if (groupId == null) return;
      await db.from('periods').insert({'group_id': groupId, 'name': title.text.trim(), 'starts_on': date.toIso8601String().substring(0,10), 'status': 'open'});
      await load();
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal membuat periode: $e'))); }
  }
  @override Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    final isAdmin = role == 'admin';
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('PENGATURAN ARISAN', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8), Text('Hak akses: ${isAdmin ? 'Admin' : 'Bendahara'}', style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 16), TextField(controller: name, enabled: isAdmin, decoration: const InputDecoration(labelText: 'Nama kelompok')),
        const SizedBox(height: 12), TextField(controller: amount, enabled: isAdmin, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Iuran default per anggota (Rp)')),
        const SizedBox(height: 12), TextField(controller: frequency, enabled: isAdmin, decoration: const InputDecoration(labelText: 'Periode pembayaran', hintText: 'Contoh: Fleksibel / setiap tanggal 5')),
        const SizedBox(height: 16), if (isAdmin) FilledButton.icon(onPressed: saving ? null : save, icon: const Icon(Icons.save), label: Text(saving ? 'Menyimpan...' : 'Simpan pengaturan')),
        if (!isAdmin) const Text('Hanya Admin yang dapat mengubah pengaturan kelompok.', style: TextStyle(color: Colors.white60)),
      ]))),
      const SizedBox(height: 12), Row(children: [const Expanded(child: Text('PERIODE ARISAN', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17))), if (isAdmin) IconButton(onPressed: addPeriod, icon: const Icon(Icons.add_circle, color: Color(0xFFE84A9B))) ]),
      if (periods.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Belum ada periode. Admin dapat menambahkan periode pertama.'))),
      ...periods.map((p) => Card(child: ListTile(leading: const Icon(Icons.event, color: Color(0xFFE84A9B)), title: Text(p['name']), subtitle: Text('Mulai: ${p['starts_on']}'), trailing: Chip(label: Text(p['status']))))),
      if (isAdmin && periods.isEmpty) OutlinedButton.icon(onPressed: addPeriod, icon: const Icon(Icons.add), label: const Text('Buat periode pertama')),
    ]);
  }
}
