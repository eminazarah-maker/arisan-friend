import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
class DrawScreen extends StatefulWidget { const DrawScreen({super.key}); @override State<DrawScreen> createState()=>_DrawScreenState(); }
class _DrawScreenState extends State<DrawScreen>{
 final db=Supabase.instance.client; bool busy=false; List<dynamic> history=[];
 Future<void> load()async{final r=await db.from('draws').select('id,drawn_at,winner:members!draws_winner_member_id_fkey(full_name),periods(name)').order('drawn_at',ascending:false);setState(()=>history=r);}
 Future<void> draw()async{
  setState(()=>busy=true);
  try{
   final periods=await db.from('periods').select('id,name').eq('status','open').order('created_at',ascending:false).limit(1);
   if(periods.isEmpty)throw Exception('Tidak ada periode aktif.');
   final result=await db.rpc('conduct_draw',params:{'p_period_id':periods.first['id']});
   if(mounted)showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('Hasil undian'),content:Text('Pemenang: ${result['winner_name']}\nNomor bukti: ${result['draw_id']}'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Tutup'))]));
   await load();
  }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  finally{if(mounted)setState(()=>busy=false);}
 }
 @override void initState(){super.initState();load();}
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
  const Icon(Icons.casino,size:56,color:Color(0xFFE84A9B)),const SizedBox(height:8),
  const Text('PENGUNDIAN TRANSPARAN',textAlign:TextAlign.center,style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
  const SizedBox(height:8),const Text('Undian dilakukan di server. Peserta harus aktif, sudah melunasi iuran periode, dan belum pernah menang pada periode yang sama.',textAlign:TextAlign.center),
  const SizedBox(height:18),FilledButton.icon(onPressed:busy?null:draw,icon:const Icon(Icons.shuffle),label:Text(busy?'Mengundi...':'MULAI UNDIAN')),
  const SizedBox(height:24),const Text('Riwayat pemenang',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
  ...history.map((h)=>ListTile(leading:const Icon(Icons.emoji_events,color:Color(0xFFE84A9B)),title:Text(h['winner']?['full_name']??'Pemenang'),subtitle:Text('${h['periods']?['name']??''} • ${h['drawn_at']}'),trailing:const Icon(Icons.verified_outlined))),
 ]);
}
