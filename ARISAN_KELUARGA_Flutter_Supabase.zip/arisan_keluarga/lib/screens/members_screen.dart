import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class MembersScreen extends StatefulWidget { const MembersScreen({super.key}); @override State<MembersScreen> createState()=>_MembersScreenState(); }
class _MembersScreenState extends State<MembersScreen> {
 final db=Supabase.instance.client;
 Future<void> edit({Map<String,dynamic>? member}) async {
  final name=TextEditingController(text: member?['full_name'] ?? ''), phone=TextEditingController(text: member?['phone'] ?? ''), address=TextEditingController(text: member?['address'] ?? '');
  final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:Text(member==null?'Tambah anggota':'Edit anggota'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
   TextField(controller:name,decoration:const InputDecoration(labelText:'Nama lengkap')),
   const SizedBox(height:10),TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Nomor WhatsApp (+62...)')),
   const SizedBox(height:10),TextField(controller:address,decoration:const InputDecoration(labelText:'Alamat (opsional)')),
  ])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Simpan'))]));
  if(ok!=true || name.text.trim().isEmpty) return;
  try {
   final data={'full_name':name.text.trim(),'phone':phone.text.trim(),'address':address.text.trim()};
   if(member==null) await db.from('members').insert(data); else await db.from('members').update(data).eq('id',member['id']);
   if(mounted) setState((){});
  } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Gagal menyimpan anggota: $e'))); }
 }
 String phoneForWa(String raw) { var n=raw.replaceAll(RegExp(r'[^0-9]'), ''); if(n.startsWith('0')) n='62${n.substring(1)}'; if(n.startsWith('8')) n='62$n'; return n; }
 Future<void> sendBulkReminders() async {
  try {
   final members=await db.from('members').select('id,full_name,phone').eq('is_active',true);
   final group=await db.from('groups').select('contribution_amount').limit(1).maybeSingle();
   final amount=(group?['contribution_amount']??10000) as num;
   final activePeriods=await db.from('periods').select('id,name').eq('status','open').order('created_at',ascending:false).limit(1);
   if(activePeriods.isEmpty){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Belum ada periode arisan yang aktif.')));return;}
   final activePeriod=activePeriods.first;
   final paidRows=await db.from('payments').select('member_id').eq('period_id',activePeriod['id']).eq('status','paid');
   final paidIds=paidRows.map((r)=>(r['member_id']??'').toString()).toSet();
   final recipients=members.where((m)=>(m['phone']??'').toString().trim().isNotEmpty && !paidIds.contains((m['id']??'').toString())).toList();
   if(recipients.isEmpty){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Tidak ada anggota yang belum lunas dengan nomor WhatsApp.')));return;}
   final confirm=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Kirim pengingat WhatsApp'),content:Text('Kirim pengingat ke ${recipients.length} anggota yang memiliki nomor WhatsApp? Pastikan template WhatsApp Business sudah disetujui dan penerima telah memberikan izin.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Kirim'))]));
   if(confirm!=true)return;
   int sent=0; final errors=<String>[];
   for(final m in recipients){
    try {
     await db.functions.invoke('send-whatsapp-reminder',body:{'phone':phoneForWa(m['phone']??''),'member_name':m['full_name'],'amount':amount,'due_date':activePeriod['name']});
     sent++;
    } catch(e){errors.add('${m['full_name']}: $e');}
   }
   if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Berhasil dikirim: $sent/${recipients.length}. Gagal: ${errors.length}. ${errors.isNotEmpty?errors.first:''}')));
  } catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Pengiriman WhatsApp API gagal: $e. Periksa konfigurasi Supabase Edge Function dan Meta.')));}
 }
 Future<void> remind(Map<String,dynamic> m) async {
  final phone=phoneForWa(m['phone'] ?? '');
  if(phone.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Nomor WhatsApp anggota belum diisi.')));return;}
  final msg='Halo ${m['full_name']}, ini pengingat dari ARISAN KELUARGA. Mohon cek pembayaran iuran arisan Anda. Terima kasih.';
  final uri=Uri.parse('https://wa.me/$phone?text=${Uri.encodeComponent(msg)}');
  if(!await launchUrl(uri,mode:LaunchMode.externalApplication) && mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('WhatsApp tidak dapat dibuka.')));
 }
 @override Widget build(BuildContext context)=>Scaffold(floatingActionButton:FloatingActionButton.extended(onPressed:()=>edit(),icon:const Icon(Icons.person_add),label:const Text('Tambah anggota')),
 body:Column(children:[Padding(padding:const EdgeInsets.fromLTRB(12,10,12,0),child:SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:sendBulkReminders,icon:const Icon(Icons.campaign),label:const Text('Kirim pengingat WhatsApp ke semua anggota')))),Expanded(child:FutureBuilder<List<dynamic>>(future:db.from('members').select().eq('is_active',true).order('full_name'),builder:(c,s){
  if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());
  if(s.hasError)return Center(child:Text('Error: ${s.error}'));
  final rows=s.data??[];
  if(rows.isEmpty)return const Center(child:Text('Belum ada anggota. Tambahkan anggota pertama.'));
  return ListView.builder(itemCount:rows.length,itemBuilder:(c,i){final m=rows[i];final full=m['full_name'] as String;return Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:5),child:ListTile(
   leading:CircleAvatar(backgroundColor:const Color(0xFF49305D),child:Text(full[0].toUpperCase())),title:Text(full),subtitle:Text(m['phone']??'Nomor WhatsApp belum diisi'),
   trailing:PopupMenuButton<String>(onSelected:(v)async{if(v=='edit')await edit(member:Map<String,dynamic>.from(m));if(v=='wa')await remind(Map<String,dynamic>.from(m));if(v=='off'){await db.from('members').update({'is_active':false}).eq('id',m['id']);if(mounted)setState((){});}},itemBuilder:(_)=>[
    const PopupMenuItem(value:'edit',child:Text('Edit anggota')),const PopupMenuItem(value:'wa',child:Text('Kirim pengingat WhatsApp')),const PopupMenuItem(value:'off',child:Text('Nonaktifkan anggota')),
   ])));
  } );
 }))]));
}
