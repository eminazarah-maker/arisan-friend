import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'members_screen.dart';
import 'payments_screen.dart';
import 'draw_screen.dart';
import 'reports_screen.dart';
import 'settings_screen.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  final pages = const [DashboardTab(), MembersScreen(), PaymentsScreen(), DrawScreen(), ReportsScreen(), SettingsScreen()];
  final labels = const ['Beranda','Anggota','Pembayaran','Undian','Laporan','Pengaturan'];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('ARISAN KELUARGA • ${labels[index]}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      actions: [IconButton(tooltip: 'Keluar', onPressed: () async {
        await Supabase.instance.client.auth.signOut();
        if (mounted) Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
      }, icon: const Icon(Icons.logout))]),
    body: IndexedStack(index: index, children: pages),
    bottomNavigationBar: NavigationBar(selectedIndex: index,
      onDestinationSelected: (v) => setState(() => index = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Beranda'),
        NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Anggota'),
        NavigationDestination(icon: Icon(Icons.payments_outlined), selectedIcon: Icon(Icons.payments), label: 'Bayar'),
        NavigationDestination(icon: Icon(Icons.casino_outlined), selectedIcon: Icon(Icons.casino), label: 'Undian'),
        NavigationDestination(icon: Icon(Icons.description_outlined), selectedIcon: Icon(Icons.description), label: 'Laporan'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Setelan'),
      ]),
  );
}
class DashboardTab extends StatefulWidget {
  const DashboardTab({super.key});
  @override State<DashboardTab> createState() => _DashboardTabState();
}
class _DashboardTabState extends State<DashboardTab> {
  Future<Map<String, dynamic>> load() async {
    final db = Supabase.instance.client;
    final group = await db.from('groups').select().limit(1).maybeSingle();
    final members = await db.from('members').select('id').eq('is_active', true);
    final payments = await db.from('payments').select('amount').eq('status', 'paid');
    final income = payments.fold<num>(0, (s, p) => s + (p['amount'] as num));
    final pending = await db.from('payments').select('id').eq('status', 'pending');
    final periods = await db.from('periods').select('id').eq('status', 'open');
    return {'group': group, 'members': members.length, 'income': income, 'pending': pending.length, 'periods': periods.length};
  }
  String rupiah(num n) => 'Rp ${n.toStringAsFixed(0).replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => '.')}';
  @override Widget build(BuildContext context) => FutureBuilder<Map<String,dynamic>>(
    future: load(), builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      if (snap.hasError) return Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('Gagal memuat dashboard: ${snap.error}')));
      final d = snap.data!; final g = d['group'] as Map<String,dynamic>?;
      return RefreshIndicator(onRefresh: () async => setState(() {}), child: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF542477), Color(0xFFB83F86)]), borderRadius: BorderRadius.circular(22)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('SELAMAT DATANG', style: TextStyle(color: Colors.white70, letterSpacing: 1.2)), const SizedBox(height: 8),
            Text(g?['name'] ?? 'ARISAN KELUARGA', style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6), Text('Iuran default ${rupiah((g?['contribution_amount'] ?? 10000) as num)} • ${g?['payment_frequency'] ?? 'Fleksibel'}', style: const TextStyle(color: Colors.white)),
          ])),
        const SizedBox(height: 16), Wrap(spacing: 10, runSpacing: 10, children: [
          _metric('Anggota aktif', '${d['members']}', Icons.groups), _metric('Uang terkumpul', rupiah(d['income'] as num), Icons.account_balance_wallet),
          _metric('Pembayaran tertunda', '${d['pending']}', Icons.pending_actions), _metric('Periode aktif', '${d['periods']}', Icons.event_available),
        ]),
        const SizedBox(height: 18), const Text('Ringkasan', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 8), const Card(child: ListTile(leading: Icon(Icons.auto_awesome, color: Color(0xFFE84A9B)), title: Text('Perhitungan otomatis'), subtitle: Text('Setiap transaksi yang dicatat langsung memperbarui total pemasukan dan laporan.'))),
        const Card(child: ListTile(leading: Icon(Icons.chat, color: Color(0xFFB56BE2)), title: Text('Pengingat WhatsApp'), subtitle: Text('Kirim pengingat ke nomor anggota melalui WhatsApp. Pengiriman massal otomatis membutuhkan API bisnis.'))),
      ]));
    });
  Widget _metric(String label, String value, IconData icon) => SizedBox(width: 165,
    child: Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start,
      children: [Icon(icon, color: const Color(0xFFE98BC4)), const SizedBox(height: 10), Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 3), Text(label, style: const TextStyle(color: Colors.white60))]))));
}
