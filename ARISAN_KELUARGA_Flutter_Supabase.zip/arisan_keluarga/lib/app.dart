import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const ink = Color(0xFF100D18);
const purple = Color(0xFF8B42C7);
const pink = Color(0xFFE84A9B);

class ArisanApp extends StatelessWidget {
  const ArisanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'ARISAN KELUARGA',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: ink,
      colorScheme: ColorScheme.fromSeed(seedColor: purple, brightness: Brightness.dark,
        primary: purple, secondary: pink, surface: const Color(0xFF211A2B)),
      appBarTheme: const AppBarTheme(backgroundColor: ink, foregroundColor: Colors.white),
      cardTheme: CardThemeData(color: const Color(0xFF211A2B), elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFF211A2B),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
      navigationBarTheme: const NavigationBarThemeData(
        backgroundColor: Color(0xFF1A1422), indicatorColor: Color(0xFF49305D),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: pink, foregroundColor: Colors.white),
    ),
    home: Supabase.instance.client.auth.currentSession == null
      ? const LoginScreen() : const HomeScreen(),
  );
}
