import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const anonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  if (url.isEmpty || anonKey.isEmpty) {
    runApp(const ProviderScope(child: ConfigurationRequiredApp()));
    return;
  }
  await Supabase.initialize(url: url, anonKey: anonKey);
  runApp(const ProviderScope(child: ArisanApp()));
}

class ConfigurationRequiredApp extends StatelessWidget {
  const ConfigurationRequiredApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Arisan Friend Jakarta',
    theme: ThemeData(colorSchemeSeed: const Color(0xFF087A55), useMaterial3: true),
    home: const Scaffold(body: Center(child: Padding(
      padding: EdgeInsets.all(24),
      child: Text('Konfigurasi Supabase belum tersedia. Jalankan aplikasi dengan --dart-define=SUPABASE_URL=... dan --dart-define=SUPABASE_ANON_KEY=...'),
    ))),
  );
}
