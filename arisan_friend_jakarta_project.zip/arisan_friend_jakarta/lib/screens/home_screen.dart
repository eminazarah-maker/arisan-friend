import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'members_screen.dart';
import 'payments_screen.dart';
import 'draw_screen.dart';
import 'reports_screen.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  final pages = const [DashboardTab(), MembersScreen(), PaymentsScreen(), DrawScreen(), ReportsScreen()];
  final labels = const ['Beranda','Anggota','Pembayaran','Undian','Laporan'];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ARISAN FRIEND JAKARTA'),
      actions: [IconButton(tooltip: 'Keluar', onPressed: () async {
        await Supabase.instance.client.auth.signOut();
        if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
      }, icon: const Icon(Icons.logout))]),
    body: pages[index],
    bottomNavigationBar: NavigationBar(selectedIndex: index,
      onDestinationSelected: (v) => setState(() => index = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Beranda'),
        NavigationDestination(icon: Icon(Icons.people_outline), label: 'Anggota'),
        NavigationDestination(icon: Icon(Icons.payments_outlined), label: 'Bayar'),
        NavigationDestination(icon: Icon(Icons.casino_outlined), label: 'Undian'),
        NavigationDestination(icon: Icon(Icons.description_outlined), label: 'Laporan'),
      ]),
  );
}
class DashboardTab extends StatefulWidget {
  const DashboardTab({super.key});
  @override State<DashboardTab> createState() => _DashboardTabState();
}
class _DashboardTabState extends State<DashboardTab> {
  Future<Map<String, dynamic>> load() async {
    final db = Supabase.instance.client;
    final group = await db.from('groups').select().limit(1).maybeSingle();
    final members = await db.from('members').select('id').eq('is_active', true);
    final payments = await db.from('payments').select('amount').eq('status', 'paid');
    final income = payments.fold<num>(0, (s, p) => s + (p['amount'] as num));
    return {'group': group, 'members': members.length, 'income': income};
  }
  @override Widget build(BuildContext context) => FutureBuilder(
    future: load(), builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      if (snap.hasError) return Center(child: Text('Gagal memuat dashboard: ${snap.error}'));
      final d = snap.data!;
      final g = d['group'] as Map<String,dynamic>?;
      return RefreshIndicator(onRefresh: () async => setState(() {}),
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Container(padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: const Color(0xFF07583F), borderRadius: BorderRadius.circular(20)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('SELAMAT DATANG', style: TextStyle(color: Color(0xFFE8D49B))),
              const SizedBox(height: 8),
              Text(g?['name'] ?? 'Arisan Friend Jakarta',
                style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
              const Text('Dashboard pengelolaan arisan', style: TextStyle(color: Colors.white70)),
            ])),
          const SizedBox(height: 16),
          Wrap(spacing: 12, runSpacing: 12, children: [
            _metric('Anggota aktif', '${d['members']}', Icons.groups),
            _metric('Pemasukan tercatat', 'Rp ${d['income']}', Icons.account_balance_wallet),
          ]),
          const SizedBox(height: 18),
          const Text('Menu pengelolaan', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          const SizedBox(height: 8),
          const ListTile(leading: Icon(Icons.people), title: Text('Data anggota'), subtitle: Text('Kelola anggota dan kontak')),
          const ListTile(leading: Icon(Icons.payments), title: Text('Pembayaran'), subtitle: Text('Catat iuran per periode')),
          const ListTile(leading: Icon(Icons.casino), title: Text('Pengundian'), subtitle: Text('Undi peserta yang memenuhi syarat')),
        ]));
    });
  Widget _metric(String label, String value, IconData icon) => SizedBox(width: 165,
    child: Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start,
      children: [Icon(icon, color: const Color(0xFF087A55)), const SizedBox(height: 10),
        Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.black54))]))));
}
