import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
class MembersScreen extends StatefulWidget { const MembersScreen({super.key}); @override State<MembersScreen> createState()=>_MembersScreenState(); }
class _MembersScreenState extends State<MembersScreen> {
 final db=Supabase.instance.client;
 Future<void> add() async {
  final name=TextEditingController(), phone=TextEditingController();
  final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Tambah anggota'),content:Column(mainAxisSize:MainAxisSize.min,children:[
   TextField(controller:name,decoration:const InputDecoration(labelText:'Nama lengkap')),
   TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Nomor WhatsApp (+62...)')),
  ]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Simpan'))]));
  if(ok==true && name.text.trim().isNotEmpty){await db.from('members').insert({'full_name':name.text.trim(),'phone':phone.text.trim()});setState((){});}
 }
 @override Widget build(BuildContext context)=>Scaffold(floatingActionButton:FloatingActionButton.extended(onPressed:add,icon:const Icon(Icons.person_add),label:const Text('Tambah')),
 body:FutureBuilder(future:db.from('members').select().order('full_name'),builder:(c,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator());
  if(s.hasError)return Center(child:Text('Error: ${s.error}'));
  final rows=s.data as List;
  if(rows.isEmpty)return const Center(child:Text('Belum ada anggota. Tambahkan anggota pertama.'));
  return ListView.builder(itemCount:rows.length,itemBuilder:(c,i){final m=rows[i];return ListTile(leading:CircleAvatar(child:Text((m['full_name'] as String)[0].toUpperCase())),title:Text(m['full_name']),subtitle:Text(m['phone']??'-'),trailing:PopupMenuButton<String>(onSelected:(v)async{if(v=='delete'){await db.from('members').update({'is_active':false}).eq('id',m['id']);setState((){});}},itemBuilder:(_)=>[const PopupMenuItem(value:'delete',child:Text('Nonaktifkan'))]));});
 }));
}
