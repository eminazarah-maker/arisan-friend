import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:excel/excel.dart' as xls;
import 'dart:typed_data';
class ReportsScreen extends StatelessWidget {
 const ReportsScreen({super.key});
 Future<Map<String,dynamic>> data()async{
  final db=Supabase.instance.client;
  final payments=await db.from('payments').select('amount,status,paid_at,members(full_name),periods(name)');
  final expenses=await db.from('expenses').select('amount,description,created_at');
  return {'payments':payments,'expenses':expenses};
 }
 Future<Uint8List> pdfBytes(Map<String,dynamic>d)async{
  final doc=pw.Document(); final p=d['payments'] as List; final e=d['expenses'] as List;
  final income=p.where((r)=>r['status']=='paid').fold<num>(0,(s,r)=>s+(r['amount'] as num));
  final out=e.fold<num>(0,(s,r)=>s+(r['amount'] as num));
  doc.addPage(pw.MultiPage(build:(c)=>[
   pw.Text('ARISAN FRIEND JAKARTA',style:pw.TextStyle(fontSize:20,fontWeight:pw.FontWeight.bold)),
   pw.Text('Laporan keuangan • ${DateTime.now().toLocal()}'),
   pw.SizedBox(height:16),pw.Text('Pemasukan: Rp ${income.toStringAsFixed(0)}'),
   pw.Text('Pengeluaran: Rp ${out.toStringAsFixed(0)}'),pw.Text('Saldo: Rp ${(income-out).toStringAsFixed(0)}'),
   pw.SizedBox(height:16),pw.Text('Daftar pembayaran',style:pw.TextStyle(fontWeight:pw.FontWeight.bold)),
   pw.Table.fromTextArray(headers:['Anggota','Periode','Nominal','Status'],data:p.map((r)=>[r['members']?['full_name']??'-',r['periods']?['name']??'-','Rp ${r['amount']}',r['status']]).toList()),
   pw.SizedBox(height:16),pw.Text('Daftar pengeluaran',style:pw.TextStyle(fontWeight:pw.FontWeight.bold)),
   pw.Table.fromTextArray(headers:['Keterangan','Nominal'],data:e.map((r)=>[r['description'],'Rp ${r['amount']}']).toList()),
  ]));return doc.save();
 }
 Future<void> exportExcel(Map<String,dynamic>d)async{
  final book=xls.Excel.createExcel();final sheet=book['Pembayaran'];
  sheet.appendRow(['Anggota','Periode','Nominal','Status','Tanggal']);
  for(final r in d['payments']){sheet.appendRow([xls.TextCellValue(r['members']?['full_name']??'-'),xls.TextCellValue(r['periods']?['name']??'-'),xls.IntCellValue((r['amount'] as num).toInt()),xls.TextCellValue(r['status']),xls.TextCellValue(r['paid_at']??'')]);}
  final exp=book['Pengeluaran'];exp.appendRow(['Keterangan','Nominal','Tanggal']);
  for(final r in d['expenses']){exp.appendRow([xls.TextCellValue(r['description']),xls.IntCellValue((r['amount'] as num).toInt()),xls.TextCellValue(r['created_at']??'')]);}
  final bytes=book.encode();if(bytes!=null)await Printing.sharePdf(bytes:Uint8List.fromList(bytes),filename:'laporan_arisan_friend_jakarta.xlsx');
 }
 @override Widget build(BuildContext context)=>FutureBuilder(future:data(),builder:(c,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator());
  if(s.hasError)return Center(child:Text('Error: ${s.error}'));
  final d=s.data!;
  return ListView(padding:const EdgeInsets.all(16),children:[
   const Text('LAPORAN ARISAN',style:TextStyle(fontWeight:FontWeight.bold,fontSize:20)),
   const SizedBox(height:12),
   Card(child:ListTile(leading:const Icon(Icons.picture_as_pdf,color:Colors.red),title:const Text('Cetak / bagikan PDF'),subtitle:const Text('Rekap pembayaran, pengeluaran dan saldo'),onTap:()async{final bytes=await pdfBytes(d);await Printing.layoutPdf(onLayout:(_)=>bytes);})),
   Card(child:ListTile(leading:const Icon(Icons.table_chart,color:Colors.green),title:const Text('Export Excel'),subtitle:const Text('Data pembayaran dan pengeluaran'),onTap:()=>exportExcel(d))),
  ]);
 });
}
