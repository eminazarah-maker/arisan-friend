import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
class PaymentsScreen extends StatefulWidget { const PaymentsScreen({super.key}); @override State<PaymentsScreen> createState()=>_PaymentsScreenState(); }
class _PaymentsScreenState extends State<PaymentsScreen>{
 final db=Supabase.instance.client;
 Future<void> record() async {
  final members=await db.from('members').select('id,full_name').eq('is_active',true).order('full_name');
  final periods=await db.from('periods').select('id,name').order('created_at',ascending:false);
  if(!mounted)return;
  if(members.isEmpty||periods.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Tambahkan anggota dan periode arisan terlebih dahulu.')));return;}
  String member=members.first['id'], period=periods.first['id']; final amount=TextEditingController();
  final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text('Catat pembayaran'),content:Column(mainAxisSize:MainAxisSize.min,children:[
   DropdownButtonFormField<String>(value:member,items:members.map<DropdownMenuItem<String>>((m)=>DropdownMenuItem(value:m['id'],child:Text(m['full_name']))).toList(),onChanged:(v)=>setD(()=>member=v!),decoration:const InputDecoration(labelText:'Anggota')),
   DropdownButtonFormField<String>(value:period,items:periods.map<DropdownMenuItem<String>>((p)=>DropdownMenuItem(value:p['id'],child:Text(p['name']))).toList(),onChanged:(v)=>setD(()=>period=v!),decoration:const InputDecoration(labelText:'Periode')),
   TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Nominal (Rp)')),
  ]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Simpan'))])));
  if(ok==true&&int.tryParse(amount.text)!=null){await db.from('payments').insert({'member_id':member,'period_id':period,'amount':int.parse(amount.text),'status':'paid','paid_at':DateTime.now().toIso8601String()});setState((){});}
 }
 @override Widget build(BuildContext context)=>Scaffold(floatingActionButton:FloatingActionButton.extended(onPressed:record,icon:const Icon(Icons.add),label:const Text('Catat iuran')),
 body:FutureBuilder(future:db.from('payments').select('id,amount,status,paid_at,members(full_name),periods(name)').order('paid_at',ascending:false),builder:(c,s){
 if(!s.hasData)return const Center(child:CircularProgressIndicator());if(s.hasError)return Center(child:Text('Error: ${s.error}'));
 final rows=s.data as List;if(rows.isEmpty)return const Center(child:Text('Belum ada pembayaran tercatat.'));
 return ListView(children:rows.map((p)=>ListTile(leading:const Icon(Icons.receipt_long,color:Color(0xFF087A55)),title:Text(p['members']?['full_name']??'Anggota'),subtitle:Text('${p['periods']?['name']??'-'} • ${p['paid_at']??''}'),trailing:Text('Rp ${p['amount']}'))).toList());
 }));
}
