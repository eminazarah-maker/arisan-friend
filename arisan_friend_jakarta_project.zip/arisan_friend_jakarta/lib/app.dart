import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ArisanApp extends StatelessWidget {
  const ArisanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Arisan Friend Jakarta',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF087A55),
        primary: const Color(0xFF087A55),
        secondary: const Color(0xFFD6AD4D),
        surface: const Color(0xFFFFFEFA),
      ),
      scaffoldBackgroundColor: const Color(0xFFF7F8F5),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF07583F), foregroundColor: Colors.white,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(elevation: 0, color: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
    ),
    home: Supabase.instance.client.auth.currentSession == null
      ? const LoginScreen() : const HomeScreen(),
  );
}
