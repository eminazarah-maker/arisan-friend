# Spesifikasi Produk — ARISAN FRIEND JAKARTA

## Tujuan
Aplikasi Android untuk pengurus kelompok arisan. Sumber data resmi adalah Supabase PostgreSQL online.

## Peran dan hak akses
| Kapabilitas | Admin | Bendahara |
|---|---:|---:|
| Login/logout | Ya | Ya |
| Lihat dashboard | Ya | Ya |
| Kelola anggota | Ya | Ya |
| Catat/lihat pembayaran | Ya | Ya |
| Catat/lihat pengeluaran | Ya | Ya |
| Kelola periode | Ya | Ya |
| Jalankan undian periode aktif | Ya | Ya |
| Lihat riwayat dan audit | Ya | Ya |
| Ubah identitas kelompok | Ya | Tidak |
| Kelola role akun | Ya | Tidak |

Pembuatan user dan pemberian role dilakukan admin melalui proses undangan yang aman di Supabase Auth. Jangan izinkan pengguna mendaftarkan dirinya sebagai admin.

## Modul dan alur
1. **Autentikasi**: email + password Supabase Auth; profil menentukan role.
2. **Kelompok**: nama kelompok, nominal iuran default, tanggal jatuh tempo.
3. **Anggota**: nama, telepon WhatsApp format internasional, alamat, status aktif/nonaktif.
4. **Periode**: nama/periode, tanggal mulai, tanggal undian, status draft/open/closed.
5. **Pembayaran**: satu pembayaran per anggota per periode; nominal, status paid/pending/void, waktu, pencatat, catatan.
6. **Undian**: hanya anggota aktif dengan pembayaran `paid` untuk periode yang dipilih. Satu undian final per periode. Server memilih pemenang; aplikasi tidak mengirim nama pilihan. Daftar peserta dan alasan kelayakan disimpan.
7. **Kas**: pengeluaran dicatat dengan uraian, nominal, tanggal, periode, dan petugas pencatat. Saldo = pembayaran berstatus paid dikurangi pengeluaran.
8. **Laporan**: PDF dan Excel berisi pembayaran dan pengeluaran. Laporan produksi sebaiknya diberi filter periode dan menyertakan daftar pemenang.
9. **WhatsApp**: pengingat dikirim melalui Edge Function menggunakan WhatsApp Business Cloud API dan template yang disetujui Meta. Pengurus harus memastikan penerima telah memberikan persetujuan (opt-in).

## Arsitektur
- Flutter Material 3 sebagai klien Android.
- Supabase Auth untuk identitas.
- PostgreSQL untuk data transaksi.
- Row Level Security (RLS) sebagai batas akses data.
- Postgres RPC `conduct_draw` untuk undian server-side.
- Supabase Edge Function untuk integrasi WhatsApp.
- Paket `pdf`, `printing`, `excel`, `share_plus` untuk ekspor.

## Prinsip transparansi undian
- Syarat peserta dan daftar peserta disimpan.
- Pemenang dipilih di server menggunakan sumber acak kriptografis.
- Satu undian final per periode dicegah dengan unique index.
- Hasil, aktor, waktu, jumlah peserta, daftar peserta, dan hash bukti dicatat.
- Untuk audit publik yang lebih kuat, sebelum undian umumkan seed/commitment dan gunakan protokol commit-reveal atau random beacon independen. Hash internal saja bukan bukti matematis bahwa operator tidak memanipulasi waktu atau data sebelum undian.

## Data dan privasi
Nomor WhatsApp dan alamat adalah data pribadi. Batasi akses hanya untuk petugas, minta persetujuan pengiriman pesan, jangan menaruh token provider pada aplikasi, dan siapkan prosedur koreksi/penghapusan sesuai kebijakan kelompok.

## Kriteria penerimaan sebelum produksi
- Uji login untuk kedua role dan penolakan akses tanpa sesi.
- Uji RLS dengan akun bendahara dan admin.
- Uji pembayaran ganda dalam satu periode.
- Uji undian tanpa peserta lunas, dengan satu peserta, dan dengan banyak peserta.
- Uji dua permintaan undian bersamaan.
- Cocokkan total laporan terhadap query database.
- Uji PDF/Excel di Android nyata.
- Uji WhatsApp hanya ke nomor uji yang sudah opt-in dan template approved.
- Aktifkan backup, monitoring, dan kebijakan pemulihan.
