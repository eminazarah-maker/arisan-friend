# ARISAN FRIEND JAKARTA — Flutter + Supabase

Starter project Android untuk manajemen arisan. Tema emerald, emas, dan putih.

## Status implementasi
- Flutter app: login email/password, dashboard, daftar anggota, pencatatan pembayaran, undian server-side, laporan PDF dan Excel.
- Supabase: skema PostgreSQL, role admin/bendahara, RLS, audit log, RPC undian.
- WhatsApp: Supabase Edge Function contoh integrasi WhatsApp Cloud API.
- Belum termasuk: konfigurasi kredensial proyek, onboarding admin, form CRUD periode/pengeluaran lengkap, pengujian produksi, signing APK, dan verifikasi template WhatsApp.

Baca `docs/SPECIFICATION.md` untuk matriks hak akses, alur bisnis, rancangan transparansi, privasi, dan kriteria penerimaan.\n\n## 1. Prasyarat
- Flutter stable dan Android SDK
- Akun Supabase
- Meta WhatsApp Business Platform untuk notifikasi (nomor bisnis, token, Phone Number ID, template pesan disetujui)

## 2. Siapkan Supabase
1. Buat project baru di Supabase.
2. Buka SQL Editor dan jalankan `supabase/migrations/0001_initial_schema.sql`.
3. Buat user admin melalui Authentication > Users.
4. Masukkan profil admin melalui SQL Editor:
   ```sql
   insert into public.profiles(id, full_name, role)
   values ('UUID_AUTH_USER_ADMIN', 'Administrator', 'admin');
   ```
5. Buat akun bendahara melalui Authentication > Users, lalu masukkan profil role `treasurer`.
6. Buat satu baris kelompok dan periode awal:
   ```sql
   insert into public.groups(name, contribution_amount, payment_due_day)
   values ('ARISAN FRIEND JAKARTA', 100000, 15);
   insert into public.periods(group_id, name, starts_on, status)
   select id, 'Periode November 2026', current_date, 'open'
   from public.groups limit 1;
   ```

## 3. Siapkan platform Android dan jalankan Flutter\nJika folder platform Android belum ada, jalankan `flutter create --platforms=android .` dari root proyek. Lalu:
```bash
flutter pub get
flutter run --dart-define=SUPABASE_URL=https://PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```
Untuk build APK:
```bash
flutter build apk --release --dart-define=SUPABASE_URL=https://PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```
APK biasanya berada di `build/app/outputs/flutter-apk/app-release.apk`.

## 4. WhatsApp
1. Siapkan WhatsApp Business Cloud API dan template `payment_reminder` berbahasa Indonesia.
2. Deploy function:
   ```bash
   supabase functions deploy send-whatsapp-reminder
   supabase secrets set WHATSAPP_TOKEN=... WHATSAPP_PHONE_NUMBER_ID=...
   ```
3. Panggil function dari aplikasi menggunakan `supabase.functions.invoke`, hanya setelah autentikasi. Jangan pernah menaruh token Meta atau service-role key di aplikasi Android.
4. WhatsApp hanya dapat mengirim pesan template yang disetujui ketika percakapan dimulai oleh bisnis; patuhi opt-in dan kebijakan Meta.

## 5. Keamanan wajib sebelum produksi
- Aktifkan MFA untuk admin bila memungkinkan.
- Jangan pernah masukkan `service_role` key ke aplikasi.
- Tinjau RLS setiap tabel dan uji menggunakan akun admin serta bendahara.
- Tambahkan pembatasan admin-only untuk mengubah role pengguna.
- Aktifkan backup Supabase dan pantau log.
- Gunakan HTTPS, validasi input, dan kebijakan retensi data.
- Undian final perlu disaksikan, menyimpan daftar peserta dan proof hash, serta dicatat dalam berita acara. Hash bukan bukti independen bahwa proses acak bebas manipulasi; untuk audit lebih kuat gunakan seed publik yang diumumkan sebelum undian dan verifikasi independen.

## 6. Catatan penting
Starter ini adalah fondasi proyek, bukan APK siap instal. Build/signing memerlukan Flutter SDK, kredensial Supabase milik pemilik aplikasi, dan pengujian pada perangkat Android. Periksa versi dependency dan lakukan `flutter analyze` serta pengujian sebelum distribusi.
