-- ARISAN FRIEND JAKARTA: jalankan di Supabase SQL Editor.
create schema if not exists extensions;\ncreate extension if not exists pgcrypto with schema extensions;

create type public.app_role as enum ('admin','treasurer');
create type public.period_status as enum ('draft','open','closed');
create type public.payment_status as enum ('paid','pending','void');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.app_role not null default 'treasurer',
  created_at timestamptz not null default now()
);
create table public.groups (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'ARISAN FRIEND JAKARTA',
  contribution_amount bigint not null check (contribution_amount > 0),
  payment_due_day int check (payment_due_day between 1 and 31),
  created_at timestamptz not null default now()
);
create table public.members (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text,
  address text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.periods (
  id uuid primary key default gen_random_uuid(),
  group_id uuid references public.groups(id) on delete restrict,
  name text not null,
  starts_on date not null,
  draw_at timestamptz,
  status public.period_status not null default 'draft',
  created_at timestamptz not null default now(),
  unique(group_id,name)
);
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.members(id),
  period_id uuid not null references public.periods(id),
  amount bigint not null check (amount > 0),
  status public.payment_status not null default 'pending',
  paid_at timestamptz,
  recorded_by uuid references public.profiles(id),
  notes text,
  created_at timestamptz not null default now(),
  unique(member_id,period_id)
);
create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  period_id uuid references public.periods(id),
  description text not null,
  amount bigint not null check (amount > 0),
  spent_at date not null default current_date,
  recorded_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);
create table public.draws (
  id uuid primary key default gen_random_uuid(),
  period_id uuid not null references public.periods(id),
  winner_member_id uuid not null references public.members(id),
  drawn_by uuid references public.profiles(id),
  drawn_at timestamptz not null default now(),
  eligible_count int not null,
  algorithm text not null default 'server-side pgcrypto random selection',
  proof_hash text not null
);
create unique index one_draw_per_period on public.draws(period_id);\ncreate table public.draw_participants (
  draw_id uuid not null references public.draws(id) on delete cascade,
  member_id uuid not null references public.members(id),
  eligible boolean not null,
  reason text,
  primary key(draw_id,member_id)
);
create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  entity text not null,
  entity_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.current_role()
returns public.app_role language sql stable security definer
set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;
create or replace function public.is_staff()
returns boolean language sql stable security definer
set search_path = public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role in ('admin','treasurer'))
$$;

alter table public.profiles enable row level security;
alter table public.groups enable row level security;
alter table public.members enable row level security;
alter table public.periods enable row level security;
alter table public.payments enable row level security;
alter table public.expenses enable row level security;
alter table public.draws enable row level security;
alter table public.draw_participants enable row level security;
alter table public.audit_logs enable row level security;

create policy "staff read profiles" on public.profiles for select to authenticated using (public.is_staff());
create policy "admin manage profiles" on public.profiles for all to authenticated using (public.current_role()='admin') with check (public.current_role()='admin');
create policy "staff read groups" on public.groups for select to authenticated using (public.is_staff());
create policy "admin manage groups" on public.groups for all to authenticated using (public.current_role()='admin') with check (public.current_role()='admin');
create policy "staff manage members" on public.members for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy "staff manage periods" on public.periods for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy "staff manage payments" on public.payments for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy "staff manage expenses" on public.expenses for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy "staff read draws" on public.draws for select to authenticated using (public.is_staff());
create policy "staff read participants" on public.draw_participants for select to authenticated using (public.is_staff());
create policy "staff read audit" on public.audit_logs for select to authenticated using (public.is_staff());

-- Undian dilakukan di server dalam satu transaksi. Tidak menerima nama pemenang dari klien.
create or replace function public.conduct_draw(p_period_id uuid)
returns jsonb language plpgsql security definer
set search_path = public, extensions as $$
declare
  v_winner public.members%rowtype;
  v_count int;
  v_draw_id uuid;
  v_hash text;
begin
  if auth.uid() is null or not public.is_staff() then
    raise exception 'Akses ditolak';
  end if;
  if not exists(select 1 from public.periods where id=p_period_id and status='open') then
    raise exception 'Periode tidak aktif';
  end if;
  if exists(select 1 from public.draws where period_id=p_period_id) then
    raise exception 'Undian periode ini sudah dilakukan';
  end if;

  create temporary table if not exists eligible_tmp(member_id uuid primary key) on commit drop;
  truncate eligible_tmp;
  insert into eligible_tmp
    select m.id from public.members m
    join public.payments p on p.member_id=m.id and p.period_id=p_period_id and p.status='paid'
    where m.is_active=true;
  select count(*) into v_count from eligible_tmp;
  if v_count=0 then raise exception 'Tidak ada peserta yang memenuhi syarat'; end if;

  select m.* into v_winner from public.members m
  join eligible_tmp e on e.member_id=m.id
  order by gen_random_bytes(32) limit 1;

  v_hash := encode(digest(
    convert_to(p_period_id::text || ':' || v_winner.id::text || ':' || clock_timestamp()::text || ':' || encode(extensions.gen_random_bytes(32),'hex'),'UTF8'),
    'sha256'),'hex');
  insert into public.draws(period_id,winner_member_id,drawn_by,eligible_count,proof_hash)
    values(p_period_id,v_winner.id,auth.uid(),v_count,v_hash) returning id into v_draw_id;
  insert into public.draw_participants(draw_id,member_id,eligible,reason)
    select v_draw_id,m.id, (e.member_id is not null),
      case when e.member_id is not null then 'Lunas dan anggota aktif' else 'Tidak memenuhi syarat' end
    from public.members m left join eligible_tmp e on e.member_id=m.id;
  insert into public.audit_logs(actor_id,action,entity,entity_id,details)
    values(auth.uid(),'conduct_draw','draws',v_draw_id::text,jsonb_build_object('period_id',p_period_id,'winner_id',v_winner.id,'eligible_count',v_count,'proof_hash',v_hash));
  return jsonb_build_object('draw_id',v_draw_id,'winner_id',v_winner.id,'winner_name',v_winner.full_name,'eligible_count',v_count,'proof_hash',v_hash);
end $$;
revoke all on function public.conduct_draw(uuid) from public;
grant execute on function public.conduct_draw(uuid) to authenticated;

-- Log transaksi dibuat oleh trigger agar aktivitas penting tercatat.
create or replace function public.log_payment_change()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.audit_logs(actor_id,action,entity,entity_id,details)
 values(auth.uid(),tg_op,'payments',coalesce(new.id,old.id)::text,
 jsonb_build_object('new_status',case when tg_op='DELETE' then null else new.status end));
 if tg_op = 'DELETE' then return old; else return new; end if;
end $$;
create trigger payments_audit after insert or update or delete on public.payments
for each row execute function public.log_payment_change();

-- Buat profil setelah admin mengundang/membuat user melalui Supabase Auth.
-- Admin awal dibuat melalui dashboard Supabase, lalu set profiles.role='admin'.
